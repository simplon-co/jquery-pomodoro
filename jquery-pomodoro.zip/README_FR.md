# Pomodoro

Créez une appli pour gérer des sessions _Pomodoro_.

![Pomodoro Timer](pomodoro.jpg)

## Les fonctionnalités :

* décider de la tâche à effectuer ;
* démarrer le minuteur (25 minutes) ;
* travailler sur la tâche jusqu'à ce que le minuteur sonne et la noter comme faite ;
* prendre une courte pause (5 minutes) ;
* tous les quatre _Pomodori_ prendre une pause un peu plus longue (15-20 minutes).

Vous avez un squelette de base contenant le code **HTML**, le code **CSS**, et qui intègre **Bootstrap** et **jQuery**.
